From the repository root:
export PYTHONPATH="$PWD/baseline_exdit_261029/api${PYTHONPATH:+:$PYTHONPATH}"

Use the existing model environment. Run toy_example.py first; it uses only temporary inputs and a custom adapter. quickstart.py invokes GRAMPA on a prepared instance. read_run.py takes an existing campaign attempt directory.
